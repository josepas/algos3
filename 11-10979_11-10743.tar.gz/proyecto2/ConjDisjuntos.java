//Clase de Conjuntos Disjuntos
//

class ConjDisjuntos {

	private int aristas[];
	private int rango[];

	//Contructor
	//Inicializa los arreglos, el de aristas del 0..n
	//y el de rango todos 1. 
	//
	public ConjDisjuntos(int n) {
		this.aristas = new int[n];
		this.rango = new int[n];
		for (int i=0; i<n; i++) {
			this.aristas[i] = i;
			this.rango[i] = 1; 
		}	
	} 
	//Busca el representante de un nodo y si el mismo
	//no es su propio representante entonces se le pone
	//de representante al representante de su representante.
	//
	public int representante(int n) {
		if ( this.aristas[n] == n ) {
			return n;
		}
		this.aristas[n] = representante(this.aristas[n]);
		return this.aristas[n];
	}

	//Une dos nodos, queda como representante el que tenga mayor rango.
	//En caso de tener rangos iguales pone arriba al segundo argumento
	//y aumenta el rango.
	//
	public void union(int n, int v) {
		n = representante(n);
		v = representante(v);

		if ( this.rango[n] == this.rango[v] ) {
			this.aristas[v] = n;
			this.rango[n]++;
		} else if ( this.rango[n] > this.rango[v] ) {
			this.aristas[v] = n;
		} else {
			this.aristas[n] = v;
		}
	}

	//Imprime el conjunto disjunto, senalando cada nodo con 
	//su representante. Ej: 1-->4 
	//
	public void imprimir(int n) {
		for (int i=0; i<n; i++) {
			System.out.println(i + " --> " + this.aristas[i]);
		}
		System.out.println();
	}
}